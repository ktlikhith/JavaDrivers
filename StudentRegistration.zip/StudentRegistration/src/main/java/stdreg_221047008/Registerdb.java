package stdreg_221047008;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Registerdb {
	public int registerStudent(Members members) throws ClassNotFoundException {
        String INSERT_USERS_SQL = "INSERT INTO Student" +
            "  (name,branch,email,phone,id) VALUES " +
            " (?,?, ?, ?, ?);";

        int result=0;

       

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/StudData", "root", "Naiklikhi@31");
            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
            //preparedStatement.setInt(1, 1);
            preparedStatement.setString(1, members.getName());
            preparedStatement.setString(2, members.getBranch());
            preparedStatement.setString(3, members.getEmail());
            preparedStatement.setString(4, members.getPhone());
            preparedStatement.setInt(5, 1);
           

            ResultSet rs = preparedStatement.executeQuery();
            
            if (rs.next()) {
            	result = rs.getInt(1);
            }

        } catch (SQLException e) {
            // process sql exception
            e.printStackTrace();
        }
        return result;
    }
}
