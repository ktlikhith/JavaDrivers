package cc221047018;

import java.io.File;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;


import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonExample {
  
  public static void main(String[] args) throws IOException {
    ObjectMapper mapper = new ObjectMapper();
    
    // create a JSON object
    JsonNode jsonNode = mapper.createObjectNode()
      .put("name", "John")
      .put("age", 30)
      .put("city", "New York");
    
    // encode the JSON object to a string
    String jsonString = mapper.writeValueAsString(jsonNode);
    
    // write the JSON string to a file
    Files.write(Paths.get("data.json"), jsonString.getBytes());
    
    // decode JSON data from a string
    JsonNode decodedJsonString = mapper.readTree(jsonString);
    System.out.println(decodedJsonString);
    
    // decode JSON data from a file
    byte[] fileData = Files.readAllBytes(new File("data.json").toPath());
    JsonNode decodedFileData = mapper.readTree(fileData);
    System.out.println(decodedFileData);
  }
}
