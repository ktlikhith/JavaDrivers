package cc221047009;
import com.mongodb.ConnectionString;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoCursor;
import org.bson.Document;

public class add {
    public static void main(String[] args) {
        // Connect to the MongoDB database
        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
       MongoDatabase database = mongoClient.getDatabase("MyDatabase");
        
        // Get a collection from the database
       MongoCollection<Document> collection = database.getCollection("MyCollection");
        
        // Create a new document to insert into the collection
        Document document = new Document();
        document.append("name", "John Doe");
        document.append("age", 30);
        document.append("email", "johndoe@example.com");
        
        // Insert the document into the collection
        collection.insertOne(document);
        
     // Find all documents in the collection
        MongoCursor<Document> cursor = collection.find().iterator();
        
        // Loop through the documents and print them
        while (cursor.hasNext()) {
            Document document1 = cursor.next();
            System.out.println(document1.toJson());
        }
        
        // Close the connection to the database
        mongoClient.close();
    }
}
