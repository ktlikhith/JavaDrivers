package cc221047018;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class StudentDataViewer {
	public List<Student> viewFromDb() throws Exception {
		Connection conn = null;
		conn = JDBCConnection.getConnection();
	    Statement stmt = conn.createStatement();
	    ResultSet rs = stmt.executeQuery("SELECT * FROM student");

	    List<Student> output = new ArrayList<>();

	    while (rs.next()) {
	        int id = rs.getInt("id");
	        String name = rs.getString("name");
	        int age = rs.getInt("age");
	        String address = rs.getString("address");
	        System.out.println("ID: " + id + ", Name: " + name + ", Age: " + age + ", Address: " + address);

	        Student student = new Student(id, name, age, address);
	        output.add(student);
	    }

	    rs.close();
	    stmt.close();
	    conn.close();

	    return output;
	}

}
