package cc221047018;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.File;
import java.io.IOException;


public class StudentDataWriter {
	
	private ObjectMapper objectMapper;
	
	public StudentDataWriter() {
        objectMapper = new ObjectMapper();
        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
    }
	
    public void writeToDb(List<Student> students) throws Exception {
    	Connection conn = null;
		conn = JDBCConnection.getConnection();
        PreparedStatement stmt = conn.prepareStatement(
            "INSERT INTO student (id, name, age, address) VALUES (?, ?, ?, ?)");
        for (Student student : students) {
            stmt.setInt(1, student.getId());
            stmt.setString(2, student.getName());
            stmt.setInt(3, student.getAge());
            stmt.setString(4, student.getAddress());
            stmt.executeUpdate();
        }
        stmt.close();
        conn.close();
    }
    
    

    public void writeToJson(List<Student> students, String filePath) throws IOException {
        String json = objectMapper.writeValueAsString(students);
        objectMapper.writeValue(new File(filePath), students);
    }
}
