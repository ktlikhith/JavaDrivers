package cc221047018;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

	
	
	
	public class JDBCConnection {
		private static final String PROPERTIES_FILE = "/db.properties";

	    public static Connection getConnection() throws SQLException, ClassNotFoundException, IOException {
	        Properties prop = new Properties();
	        try (InputStream inputStream = JDBCConnection.class.getResourceAsStream(PROPERTIES_FILE)) {
	            prop.load(inputStream);
	        } catch (IOException e) {
	            System.err.println("Error loading db.properties: " + e.getMessage());
	            e.printStackTrace();
	        }

	        String url = prop.getProperty("url");
	        String username = prop.getProperty("username");
	        String password = prop.getProperty("password");

	        Class.forName("com.mysql.cj.jdbc.Driver");
	        Connection conn = DriverManager.getConnection(url, username, password);
	        return conn;
	    }
	}