package cc221047018;

import java.io.File;


import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.google.gson.Gson;

public class StudentDataReader {
	public List<Student> readFromJson(String filePath) throws Exception {
	    Gson gson = new Gson();
	    File file = new File(filePath);
	    FileReader reader = new FileReader(file);
	    Student[] students = gson.fromJson(reader, Student[].class);
	    List<Student> studentList = new ArrayList<Student>();
	    
            System.out.println("\nSuccessfully read data from JSON source.");
            for (Student student : students) {
                System.out.printf("ID: %d, Name: %s, Age: %d%n",
                        student.getId(), student.getName(), student.getAge());
            }
        
	    Scanner scanner = new Scanner(System.in);
	    System.out.println("Do you want to update the database with the read data? (YES/NO)");
	    String choice = scanner.nextLine();
	    
	    if (choice.equalsIgnoreCase("YES")) {
	        Connection conn = null;
	        PreparedStatement stmt = null;
	        try {
	        	conn = JDBCConnection.getConnection();
	            stmt = conn.prepareStatement("INSERT INTO student (id, name, age, address) VALUES (?, ?, ?, ?)");
	            for (Student student : students) {
	                stmt.setInt(1, student.getId());
	                stmt.setString(2, student.getName());
	                stmt.setInt(3, student.getAge());
	                stmt.setString(4, student.getAddress());
	                stmt.executeUpdate();
	                studentList.add(student);
	            }
	            System.out.println("Successfully updated the database with the read data.");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        } finally {
	            if (stmt != null) {
	                stmt.close();
	            }
	            if (conn != null) {
	                conn.close();
	            }
	        }
	    } else {
	        for (Student student : students) {
	            studentList.add(student);
	        }
	    }
	    
	    return studentList;
	}

}
