package cc221047018;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        StudentDataReader dataReader = new StudentDataReader();
        StudentDataViewer dataViewer;
        StudentDataWriter dataWriter;
        dataViewer = new StudentDataViewer();
		dataWriter = new StudentDataWriter();
        while (true) {
            System.out.println("\nSelect an option:");
            System.out.println("1. Read student data from JSON source");
            System.out.println("2. Write student data to database");
            System.out.println("3. View student data in database");
            System.out.println("4. Export student data from database to JSON file");
            System.out.println("5. Exit");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline character
            switch (choice) {
                case 1:
                    System.out.print("Enter the path to the JSON source file: ");
                    String jsonSource = scanner.nextLine();
                    try {
                    	//List<Student> students = dataReader.readFromJson(jsonSource);

                        dataReader.readFromJson(jsonSource);
                        
                    } catch (IOException e) {
                        System.out.println("Failed to read from JSON source: " + e.getMessage());
                    }
                    break;
                case 2:
                	addStudentFromInput(scanner);
                    break;
                case 3:
                    try {
                        //dataViewer = new StudentDataViewer(DB_URL, DB_USERNAME, DB_PASSWORD);
                    	dataViewer = new StudentDataViewer();
                        dataViewer.viewFromDb();
                    } catch (SQLException e) {
                        System.out.println("Failed to view student data in database: " + e.getMessage());
                    }
                    break;
                case 4:
                    System.out.print("Enter the path to the output JSON file: ");
                    String jsonOutput = scanner.nextLine();
                    try {
                        List<Student> students = dataViewer.viewFromDb();
                        dataWriter.writeToJson(students, jsonOutput);
                        System.out.println("Successfully exported student data to JSON file.");
                    } catch (SQLException e) {
                        System.out.println("Failed to export student data to JSON file: " + e.getMessage());
                    }
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
                    break;
                    
            }
            if (choice == 5) 
                break;
        }
    }
    
    private static void addStudentFromInput(Scanner scanner) throws Exception {
    	StudentDataWriter dataWriter;
    	dataWriter = new StudentDataWriter();

        System.out.println("Enter the student data in the format 'id,name,age,address', one per line (type 'done' when finished):");
        while (true) {
            String input = scanner.nextLine();
            if (input.equals("done")) {
                break;
            }
            String[] parts = input.split(",");
            if (parts.length != 4) {
                System.out.println("Invalid input format, please try again.");
                continue;
            }

            String idStr = parts[0];
            String name = parts[1];
            String ageStr = parts[2];
            String address = parts[3];
            int id;
            int age;
            try {
                id = Integer.parseInt(idStr);
                age = Integer.parseInt(ageStr);
            } catch (NumberFormatException e) {
                System.out.println("Invalid number format, please try again.");
                continue;
            }
            Student student = new Student(id, name, age, address);
            try {
                dataWriter.writeToDb(List.of(student));
                System.out.printf("Successfully wrote student data to database: ID %d, Name %s, Age %d, Address %s%n",
                        student.getId(), student.getName(), student.getAge(), student.getAddress());
            } catch (SQLException e) {
                System.out.println("Failed to write student data to database: " + e.getMessage());
            }
        }
    }

}

