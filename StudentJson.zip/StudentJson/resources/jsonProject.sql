create database mydb;

use mydb;

CREATE TABLE student(
    id INT PRIMARY KEY,
    name VARCHAR(255),
    age INT,
    address VARCHAR(255)
);

select * from student;